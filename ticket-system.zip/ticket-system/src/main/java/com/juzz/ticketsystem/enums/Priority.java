package com.juzz.ticketsystem.enums;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
