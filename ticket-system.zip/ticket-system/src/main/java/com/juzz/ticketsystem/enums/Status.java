package com.juzz.ticketsystem.enums;

public enum Status {
    OPEN,
    IN_PROGRESS,
    RESOLVED,
    CLOSED
}
